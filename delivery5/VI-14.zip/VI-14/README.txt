This project is ready to run as is.
The project was developed with google chrome, and may not work in other browsers.